<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <img src="dzik.png" class="logo">
        <nav>
            <a href="strona.html" class="links">Strona główna</a>
            <a href="formularz.php" class="links">Formularz</a>
            <a href="tabela.php" class="links">Filmy</a>
        </nav>
    </header>

    <main>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $host = 'localhost';
            $username = 'root';
            $password = '';
            $database = 'kacperkino';

            $conn = new mysqli($host, $username, $password, $database);

            if ($conn->connect_error) {
                die("Błąd połączenia: " . $conn->connect_error);
            }

            $imie = $conn->real_escape_string($_POST['imie']);
            $nazwisko = $conn->real_escape_string($_POST['nazwisko']);

            $sql = "INSERT INTO SPRZEDAWCY (IMIE, NAZWISKO) VALUES ('$imie', '$nazwisko')";
            if ($conn->query($sql) === TRUE) {
            } else {
                $conn->error . '</p>';
            }

            $conn->close();
        }
        ?>

        <form method="post" action="">
            <h2>Dodaj Sprzedawcę</h2>
            <input type="text" name="imie" placeholder="Imię" required>
            <input type="text" name="nazwisko" placeholder="Nazwisko" required>
            <input type="submit" value="Dodaj">
        </form>
    </main>

    <footer>
    <p id="animacja"><b>©Kacper Malinowski 2024</b></p>
    <script src="skrypt.js"></script>
</body>
</html>
