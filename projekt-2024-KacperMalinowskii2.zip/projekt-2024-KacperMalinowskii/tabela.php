<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <img src="dzik.png" class="logo">
        <nav>
            <a href="strona.html" class="links">Strona główna</a>
            <a href="formularz.php" class="links">Formularz</a>
            <a href="tabela.php" class="links">Filmy</a>
        </nav>
    </header>

    <main>

        <section id="filmy">
            <h2>Lista Filmów</h2><br>
            <?php
            $host = 'localhost';
            $username = 'root'; 
            $password = '';
            $database = 'kacperkino'; 

            $conn = new mysqli($host, $username, $password, $database);

            if ($conn->connect_error) {
                die("Błąd połączenia: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM FILMY";
            $result = $conn->query($sql);

            echo "<table>";
            echo "<tr><th>ID</th><th>Tytuł</th><th>Reżyser</th><th>Czas Trwania (min)</th></tr>";
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['ID'] . "</td>";
                    echo "<td>" . $row['TYTUL'] . "</td>";
                    echo "<td>" . $row['REZYSER'] . "</td>";
                    echo "<td>" . $row['CZAS_TRWANIA_MIN'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Brak filmów w bazie danych.</td></tr>";
            }
            echo "</table>";

            $conn->close();
            ?>
        </section>
    </main>

    <footer>
    <p id="animacja"><b>©Kacper Malinowski 2024</b></p>
    </footer>
    <script src="skrypt.js"></script>
</body>
</html>
