const tekst = document.querySelector("#stopka");
let position = 2000;

function animate() {
    position += 5;
    tekst.style.left = position + 'px';

    if (position > window.innerWidth) {
        position = -50;
    }
    requestAnimationFrame(animate);
}
animate();